﻿namespace FormLogin
{
    partial class FormH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnItt = new System.Windows.Forms.Button();
            this.btnrnk = new System.Windows.Forms.Button();
            this.btnClg = new System.Windows.Forms.Button();
            this.btnCnt = new System.Windows.Forms.Button();
            this.btnSL = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label1.Location = new System.Drawing.Point(105, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Xin chào ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(171, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(392, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Chào Mừng Bạn Đến Với Vòng Quay May Mắn";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnItt
            // 
            this.btnItt.BackColor = System.Drawing.Color.Silver;
            this.btnItt.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnItt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnItt.Location = new System.Drawing.Point(316, 356);
            this.btnItt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnItt.Name = "btnItt";
            this.btnItt.Size = new System.Drawing.Size(131, 62);
            this.btnItt.TabIndex = 17;
            this.btnItt.Text = "INTRUCTION";
            this.btnItt.UseVisualStyleBackColor = false;
            this.btnItt.Click += new System.EventHandler(this.btnItt_Click);
            // 
            // btnrnk
            // 
            this.btnrnk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnrnk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrnk.ForeColor = System.Drawing.Color.Olive;
            this.btnrnk.Location = new System.Drawing.Point(417, 274);
            this.btnrnk.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnrnk.Name = "btnrnk";
            this.btnrnk.Size = new System.Drawing.Size(119, 62);
            this.btnrnk.TabIndex = 16;
            this.btnrnk.Text = "RANK";
            this.btnrnk.UseVisualStyleBackColor = false;
            this.btnrnk.Click += new System.EventHandler(this.btnrnk_Click);
            // 
            // btnClg
            // 
            this.btnClg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnClg.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClg.ForeColor = System.Drawing.Color.Green;
            this.btnClg.Location = new System.Drawing.Point(233, 274);
            this.btnClg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnClg.Name = "btnClg";
            this.btnClg.Size = new System.Drawing.Size(119, 62);
            this.btnClg.TabIndex = 15;
            this.btnClg.Text = "CHALLENGE";
            this.btnClg.UseVisualStyleBackColor = false;
            this.btnClg.Click += new System.EventHandler(this.btnClg_Click);
            // 
            // btnCnt
            // 
            this.btnCnt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.btnCnt.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCnt.ForeColor = System.Drawing.Color.Teal;
            this.btnCnt.Location = new System.Drawing.Point(417, 188);
            this.btnCnt.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCnt.Name = "btnCnt";
            this.btnCnt.Size = new System.Drawing.Size(119, 62);
            this.btnCnt.TabIndex = 14;
            this.btnCnt.Text = "CONNECT";
            this.btnCnt.UseVisualStyleBackColor = false;
            this.btnCnt.Click += new System.EventHandler(this.btnCnt_Click);
            // 
            // btnSL
            // 
            this.btnSL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnSL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnSL.Location = new System.Drawing.Point(233, 188);
            this.btnSL.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSL.Name = "btnSL";
            this.btnSL.Size = new System.Drawing.Size(119, 62);
            this.btnSL.TabIndex = 13;
            this.btnSL.Text = "SOLO";
            this.btnSL.UseVisualStyleBackColor = false;
            this.btnSL.Click += new System.EventHandler(this.btnSL_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(299, 143);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 16);
            this.label3.TabIndex = 12;
            this.label3.Text = "Vui lòng chọn chế độ chơi";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.label4.Location = new System.Drawing.Point(199, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 20);
            this.label4.TabIndex = 18;
            this.label4.Text = "Nhom4";
            // 
            // FormH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnItt);
            this.Controls.Add(this.btnrnk);
            this.Controls.Add(this.btnClg);
            this.Controls.Add(this.btnCnt);
            this.Controls.Add(this.btnSL);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormH";
            this.Text = "Trang chủ trò chơi vòng quay may mắn";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnItt;
        private System.Windows.Forms.Button btnrnk;
        private System.Windows.Forms.Button btnClg;
        private System.Windows.Forms.Button btnCnt;
        private System.Windows.Forms.Button btnSL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}